package com.example.sadokmm.myapplication;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;

import static com.example.sadokmm.myapplication.LoginActivity.myCon;

public class MainActivity extends AppCompatActivity {

    ActionBar toolbar;
    BottomNavigationView mBottomNavigationView;
    static Vector<Personne> list=new Vector<Personne>();
    private FragmentManager manager= getSupportFragmentManager();
    static String message;

    Fragment f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar=getSupportActionBar();
        toolbar.setTitle("Home");
        remplirListe();

        loadHomeFragment();


        // DBBBB

        String name="Sadok";
        String des="ISG";
        String pass="1234";
        Bitmap av;
        av=BitmapFactory.decodeResource(getResources(),R.drawable.sadok);

        /*try{
            DBconnection db= new DBconnection(this);
            //db.create(name,des,pass,av);
            db.insert("Sadok","ISG","1234");
            db.insert("mimi","ui","1234");

            db.insert("kiki","iii","1234");

            //list=db.charger();
        }
        catch (Exception e){
            TextView t=(TextView)findViewById(R.id.textView3);
            t.setText(e.toString());
        }
*/






        setupBottomNav();
        //Floating Button

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Snackbar.make(view, "Here's a Snackbar", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/
                addPic();
            }
        });



        //
        final FragmentManager fragmentManager = getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();


        Intent intent = getIntent();
         message = intent.getStringExtra("name");

    }




    //Ajout photo
    //





public void setupBottomNav() {
    mBottomNavigationView = (BottomNavigationView) findViewById(R.id.navigationView);

    mBottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.home:
                    loadHomeFragment();
                    toolbar.setTitle("Home");


                    return true;
                case R.id.list:
                    loadGridFragment();
                    toolbar.setTitle("Home");
                    return true;
                case R.id.profile:
                    loadProfile();
                    toolbar.setTitle(myCon.getName(message));
                    return true;
            }
            return false;
        }
    });
}

    //Remplir liste
   void remplirListe() {
       /* Bitmap im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.amine);
        list.add(new Personne(0,"Amine", "Ahmed Amine Rassas ISSAT", im));
        im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.boha);
        list.add(new Personne(1,"Boha", "Baha Eddine Bettaieb ISGs", im));
        im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.fedi);
        list.add(new Personne(2,"Fedi", "Fedi Abdelhamid Kantaoui FLSHs", im));
        im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.monta);
        list.add(new Personne(3,"Monta", "Montassar Yakoubi ISIMM", im));
        /*ListView lv=(ListView)findViewById(R.id.lv);
        lv.setAdapter(mya);*/


       Bitmap im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.sadok);
       myCon.insertPersonne(1000,"Sadok","Sadok Mourad Mhiri",im);
       im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.amine);
       myCon.insertPersonne(1001,"Amine","Ahmed Amine Rassas",im);
       im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.fedi);
       myCon.insertPersonne(1002,"Fedi","Fedi Abdelhamid Kantaoui",im);
       im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.boha);
       myCon.insertPersonne(1003,"Baha","Baha Eddine Bettaieb",im);
       im = (Bitmap) BitmapFactory.decodeResource(getResources(), R.drawable.monta);
       myCon.insertPersonne(1004,"Monta","Montassar Yaakoubi",im);

       list=myCon.charger();




   }





    public void loadHomeFragment() {

        homeFrag fragment = new homeFrag();
        //fragment.applyGrid();
        //fragment.aa();
        manager.beginTransaction()
                .replace(R.id.container,fragment)
                .commit();

    }

    private void loadGridFragment() {

        listFrag fragment = new listFrag();
        manager.beginTransaction()
                .replace(R.id.container,fragment)
                .commit();
    }

    private void loadProfileFragment() {

        artisteFrag fragment = new artisteFrag();
        manager.beginTransaction()
                .replace(R.id.container,fragment)
                .commit();
    }


    private void addPic(){
        Ajout fragment = new Ajout();
        manager.beginTransaction()
                .replace(R.id.container,fragment)
                .addToBackStack(null)
                .commit();
    }

    private void loadProfile(){
        profile fragment = new profile();
        manager.beginTransaction()
                .replace(R.id.container,fragment)
                .addToBackStack(null)
                .commit();
    }



    //back press


    @Override
    public boolean dispatchKeyEvent (KeyEvent event) {

        if (event.getAction()==KeyEvent.ACTION_DOWN && event.getKeyCode()==KeyEvent.KEYCODE_BACK) {
           loadHomeFragment();
            return true;
        }
        return false;
    }
}
