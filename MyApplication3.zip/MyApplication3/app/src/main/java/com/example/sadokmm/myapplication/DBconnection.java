package com.example.sadokmm.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Vector;

public class DBconnection extends SQLiteOpenHelper {
    public static final String Dbname="test15.db";
    public static final int Version=1;
    public static int id=1;
    public static int idItem=1000;
    public String c_etat;

    public DBconnection(Context context){
        super(context,Dbname,null,Version);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String req1="DROP TABLE IF EXISTS `Admins` ;";
        String req="CREATE TABLE IF NOT EXISTS `Admins` (`id`	INTEGER,`name`	TEXT,`email` TEXT, `pass` TEXT,`av` BLOB, PRIMARY KEY(`id`,`email`));";
        String req2="CREATE TABLE IF NOT EXISTS `Personne` (`id`	INTEGER,`name`	TEXT,`des` TEXT, `av` BLOB, PRIMARY KEY(`id`));";

        //String req2="CREATE TABLE IF NOT EXISTS `AdminProduct` (`IdAdmin`	INTEGER,`ProductName`	TEXT, FOREIGN KEY(`IdAdmin`) REFERENCES `Admins`(`id`));";
        //String req3="CREATE VIEW IF NOT EXISTS AdminsProduct as SELECT name,ProductName,IdAdmin FROM Admins LEFT JOIN AdminProduct ON Admins.id=AdminProduct.IdAdmin ";

        sqLiteDatabase.execSQL(req1);

        sqLiteDatabase.execSQL(req);
        sqLiteDatabase.execSQL(req2);
        //sqLiteDatabase.execSQL(req3);


    }

    public void insertp(String n,int ide){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("id",ide);
        cv.put("ProductName",n);
        db.insert("AdminProduct",null,cv);
    }


    public ArrayList getRec(){
        ArrayList a=new ArrayList();
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM AdminsProduct ",null);
        c.moveToFirst();
        while (c.isAfterLast()==false){
            a.add(c.getString(c.getColumnIndex("name")) + c.getString(c.getColumnIndex("  ProdcutName ")) + c.getString(c.getColumnIndex("  IdAdmin")));
        }
        return a;
    }

    public void create(){

        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c = db.rawQuery("Select * FROM Admins ", null);

        if (!(c!=null)){
            db=this.getWritableDatabase();
            String req="INSERT INTO Admins (id,name) VALUES ('0','Sadokk','1234')";


            db.execSQL(req);}
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String req="DROP TABLE IF EXISTS Admins";

        sqLiteDatabase.execSQL(req);
        onCreate(sqLiteDatabase);
    }

    public void insertAdmins(int id,String name,String email,String pass,Bitmap im){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        byte[] b=getByteArray(im);
        cv.put("name",name);
        cv.put("id",id);
        cv.put("email",email);
        cv.put("pass",pass);
        cv.put("av",b);
        db.insert("Admins",null,cv);

    }

    public void insertPersonne(int id,String name,String des,Bitmap im){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        byte[] b=getByteArray(im);
        cv.put("name",name);
        cv.put("id",id);
        cv.put("des",des);
        cv.put("av",b);
        db.insert("Personne",null,cv);

    }


    public Vector<Personne> charger() {
        Vector<Personne> al = new Vector<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("Select * FROM Personne ", null);


        Bitmap im;
        c.moveToFirst();
        while (c.isAfterLast() == false) {
            im=getBitmap(c.getBlob(c.getColumnIndex("av")));
            al.add(new Personne(Integer.parseInt(c.getString(c.getColumnIndex("id"))) ,  c.getString(c.getColumnIndex("name")) ,  c.getString(c.getColumnIndex("des")),im));
            c.moveToNext();
        }


        return al;
    }


   /* public ArrayList charger() {
        ArrayList al = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("Select * FROM Admins ", null);



            c.moveToFirst();
            while (c.isAfterLast() == false) {
                al.add(c.getString(c.getColumnIndex("id")) + " " + c.getString(c.getColumnIndex("name")));
                c.moveToNext();
            }


        return al;
    } */

    public void supp(int id){
        SQLiteDatabase db=this.getWritableDatabase();
        String req="DELETE FROM Admins WHERE id='"+ Integer.toString(id)+"'";
        db.execSQL(req);
    }

    public int lastItemId(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("Select * FROM Admins ",null);

        if (!((c != null) && (c.getCount() > 0))) return 0;
        else {
            c.moveToLast();
            return Integer.parseInt(c.getString(c.getColumnIndex("id")));
        }
    }

    public int lastItemIdPersonne(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("Select * FROM Personne ",null);

        if (!((c != null) && (c.getCount() > 0))) return 0;
        else {
            c.moveToLast();
            return Integer.parseInt(c.getString(c.getColumnIndex("id")));
        }
    }

    public void update(int id,String name ){

        SQLiteDatabase db=this.getWritableDatabase();
        String req="UPDATE Admins SET name='" +name+"' WHERE id='"+Integer.toString(id)+"'";
        db.execSQL(req);
    }

    public String getName(String name){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM Admins WHERE name='"+name+"';",null);

        if (!((c != null) && (c.getCount() > 0)))
            return "no username found: "+name;
        else {
            c.moveToFirst();
            return c.getString(c.getColumnIndex("name"));
        }
    }




    public String getNamePersonne(String name){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM Personne WHERE name='"+name+"';",null);

        if (!((c != null) && (c.getCount() > 0)))
            return "no username found: "+name;
        else {
            c.moveToFirst();
            return c.getString(c.getColumnIndex("name"));
        }
    }




    public String getDesPersonne(String name){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT des FROM Personne WHERE name='"+name+"';",null);

        if (!((c != null) && (c.getCount() > 0)))
            return "no username found: "+name;
        else {
            c.moveToFirst();
            return c.getString(c.getColumnIndex("des"));
        }
    }


    public String getPass(String name){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT pass FROM Admins WHERE name='"+name+"';",null);

        if (!((c != null) && (c.getCount() > 0)))
            return "no username found: "+name;
        else {
            c.moveToFirst();
            return c.getString(c.getColumnIndex("pass"));
        }
    }


    public int getId(String name){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM Admins WHERE name='"+name+"';",null);

        if (!((c != null) && (c.getCount() > 0)))
            return 0;
        else {
            c.moveToFirst();
            return Integer.parseInt(c.getString(c.getColumnIndex("id")));
        }
    }


    public Bitmap getAv(String name){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM Admins WHERE name='"+name+"';",null);

        if (!((c != null) && (c.getCount() > 0)))
            return null;

        else {

            c.moveToFirst();
            return getBitmap(c.getBlob(c.getColumnIndex("av")));
        }
    }

    public String getEmail(String email){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT pass FROM Admins WHERE email='"+email+"';",null);

        if (!((c != null) && (c.getCount() > 0)))
            return "no account found for: "+email;
        else {
            c.moveToFirst();
            return c.getString(c.getColumnIndex("email"));
        }
    }


    public byte[] getByteArray(Bitmap bitmap) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.WEBP, 10, bos);
        //String StrImgProcuration = Base64.encodeToString(bos.toByteArray(), 0);

        return bos.toByteArray();
    }





    // convert byte array to Bitmap
    public Bitmap getBitmap(byte[] bitmap) {
        return BitmapFactory.decodeByteArray(bitmap , 0, bitmap.length);
    }
}
