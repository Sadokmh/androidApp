package com.example.sadokmm.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.support.v4.provider.FontsContractCompat.FontRequestCallback.RESULT_OK;
import static com.example.sadokmm.myapplication.LoginActivity.myCon;
import static com.example.sadokmm.myapplication.MainActivity.list;

public class Ajout extends Fragment {


    private FragmentManager manager=getFragmentManager();
    private Bitmap myNewImage;
    private  ImageButton b2;
    private int idPersonne;

    int id2=1;


    public Ajout() {
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.ajout,container,false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        myNewImage=BitmapFactory.decodeResource(getResources(),R.drawable.placeholder_pic);
        //opencam();
        ImageButton b=(ImageButton) getView().findViewById(R.id.btnAdd);
        ImageView b2=(ImageView)getView().findViewById(R.id.addIm);

        idPersonne=myCon.lastItemIdPersonne();

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseSrouceImage();
            }
        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    EditText name = (EditText) getView().findViewById(R.id.name);
                    EditText dess = (EditText) getView().findViewById(R.id.dess);
                    myCon.insertPersonne(++idPersonne,name.getText().toString(),dess.getText().toString(),myNewImage);
                    getActivity().getSupportFragmentManager().popBackStack();
                }
                catch (Exception e){
                    EditText name = (EditText) getView().findViewById(R.id.name);
                    name.setText(e.toString());
                }

            }
        });
    }



private void chooseSrouceImage(){
    AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
    alert.setIcon(R.drawable.ci);
    alert.setTitle("wini tasswira ? :D ");
    alert.setPositiveButtonIcon(getContext().getDrawable(R.drawable.ic_camera));
    alert.setPositiveButton("Camera", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {


            opencam();
        }
    });
    alert.setNegativeButtonIcon(getContext().getDrawable(R.drawable.ic_photo_library));
    alert.setNegativeButton("Galerie", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {
            openGalerie();
        }
    });
    alert.show();
}


    void opencam() {

        try {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (takePictureIntent.resolveActivity(getContext().getPackageManager()) != null) {
                startActivityForResult(takePictureIntent, id2);
            }

        }
        catch (Exception e){
            EditText name = (EditText) getView().findViewById(R.id.name);
            name.setText(e.toString());
        }
    }





int id_intentImg=100;
private void openGalerie(){
        Intent intentImg=new Intent(Intent.ACTION_GET_CONTENT);
        intentImg.setType("image/*");
        startActivityForResult(intentImg,id_intentImg);
}







    public void onActivityResult(int requestCode, int resultCode, Intent data) {

            super.onActivityResult(requestCode,resultCode,data);

        if (resultCode == Activity.RESULT_OK && requestCode == id_intentImg){
            try {
                 Uri uri = data.getData();

                 InputStream inputStream = getContext().getContentResolver().openInputStream(uri);
                 Bitmap decodeStream = BitmapFactory.decodeStream(inputStream);

                myNewImage=decodeStream;
                ImageView b2=(ImageView) getView().findViewById(R.id.addIm);
                b2.setImageURI(uri);


            }
            catch (Exception e){
                Toast.makeText(getContext(),e.toString(),Toast.LENGTH_LONG).show();
            }
        }


        else if (requestCode == id2 && resultCode == Activity.RESULT_OK) {


            Bundle extras = data.getExtras();
            myNewImage = (Bitmap) extras.get("data");
            ImageView imageView=(ImageView)getView().findViewById(R.id.addIm);
            imageView.setImageBitmap(myNewImage);


        }
        else {
            ImageView imageView=(ImageView)getView().findViewById(R.id.addIm);
            imageView.setImageBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.placeholder_pic));
        }

    }



        // save img






}
