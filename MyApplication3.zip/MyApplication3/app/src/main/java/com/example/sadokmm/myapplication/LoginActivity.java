package com.example.sadokmm.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private FragmentManager manager= getSupportFragmentManager();

    static DBconnection myCon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText user = (EditText) findViewById(R.id.user);
        final EditText pass = (EditText) findViewById(R.id.pass);
        final ImageButton login = (ImageButton) findViewById(R.id.imageButton);
        final ImageButton newC = (ImageButton) findViewById(R.id.newC);
        final FragmentManager fragmentManager = getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();


        //converting img
        Bitmap sadok= BitmapFactory.decodeResource(getResources(),R.drawable.sadok);
        Bitmap amine= BitmapFactory.decodeResource(getResources(),R.drawable.amine);



        myCon = new DBconnection(this);

        myCon.insertAdmins(0,"sadok","sadok@gmail.com","1223",sadok);
        myCon.insertAdmins(1,"amine","amine@gmail.com","lol123",amine);




        // Button on click Listenner :

        newC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            try {
                newaccount fragment = new newaccount();
                manager.beginTransaction()
                        .replace(R.id.container, fragment)
                        .addToBackStack(null)
                        .commit();
            }
            catch (Exception e){
                TextView t=(TextView)findViewById(R.id.t);
                t.setText(e.toString());
            }
            }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            /*db.create();
            db.insert("Mourad", "555", ++id);*/
                // chg();

                /*final Intent myintent;
                myintent=new Intent(getApplicationContext(),testlog.class);
                startActivity(myintent);*/
                try {

                    String usernamedb=myCon.getName(user.getText().toString());
                    String username=user.getText().toString();
                    String passworddb=myCon.getPass(user.getText().toString());
                    String password=pass.getText().toString();
                    Bitmap image;

                    /*if (myCon.getAv(user.getText().toString())==null)
                        Toast.makeText(getApplicationContext(),"no image found ", Toast.LENGTH_LONG).show();*/

                    //else image=myCon.getAv(user.getText().toString());


                     if (usernamedb.equals(username) && (passworddb.equals(password)) )
                    {
                        Toast.makeText(getApplicationContext(), "Welcome", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.putExtra("name",username);
                        startActivity(intent);
                    }
                    else if (usernamedb.equals("no username found: "+username))
                        Toast.makeText(getApplicationContext(), myCon.getName(user.getText().toString()), Toast.LENGTH_LONG).show();
                    else if (usernamedb.equals(username) && !(passworddb.equals(password)) )
                        Toast.makeText(getApplicationContext(), "Invalid password", Toast.LENGTH_LONG).show();






                }
                catch (Exception e){
                    TextView t=(TextView)findViewById(R.id.t);
                    t.setText(e.toString());
                }
            }
        });

    }
}
